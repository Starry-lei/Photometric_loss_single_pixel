These files were automatically produced by exporting a project 
from the GSN Composer website https://www.gsn-lib.org to a stand-alone web application, 
which runs independently from the GSN Composer front end.

The web application can be run offline/locally in a web browser or can be included into another website.

LICENSE.txt contains the copying conditions.
INSTALL.txt describes how to run the web application.

Please get in contact at https://www.gsn-lib.org if you have questions, requests, or suggestions for improvement.
Your feedback is very much appreciated.