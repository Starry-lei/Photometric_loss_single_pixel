These C++ sources were automatically produced by exporting a 
shader from the GSN Composer website https://www.gsn-lib.org 

LICENSE.txt contains the copying conditions (MIT license).
INSTALL.txt describes how to compile and run the sources.

Please get in contact at https://www.gsn-lib.org if you have questions, requests, or suggestions for improvement.
Your feedback is very much appreciated.